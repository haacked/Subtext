For details on how to install Subtext, check out:
http://www.subtextproject.com/docs/installation.aspx

For details on how to upgrade an existing installation of Subtext,
check out:
http://www.subtextproject.com/docs/upgrading.aspx

If you're deploying manually, you'll want to deploy the contents of the 
Subtext.Web folder into your Webroot.